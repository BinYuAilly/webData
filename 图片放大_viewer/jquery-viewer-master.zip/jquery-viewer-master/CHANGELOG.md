# Changelog

## 1.0.1 (Dec 14, 2019)

- Register as a plugin only when both the jQuery and Cropper.js are existing.

## 1.0.0 (Apr 1, 2018)

- Just released as a stable version.

## 1.0.0-beta (Mar 15, 2018)

- Simplify `undefined` checking.

## 1.0.0-alpha (Mar 10, 2018)

- Init.
