<!-- Please fill the following template -->

### Version information

* fluent-ffmpeg version:
* ffmpeg version:
* OS:

### Code to reproduce

```js


```

(note: if the problem only happens with some inputs, include a link to such an input file)

### Expected results



### Observed results



### Checklist

<!-- you may delete that checklist when you have checked everything -->

* [ ] I have read the [FAQ](https://github.com/fluent-ffmpeg/node-fluent-ffmpeg/wiki/FAQ)
* [ ] I tried the same with command line ffmpeg and it works correctly (hint: if the problem also happens this way, this is an ffmpeg problem and you're not reporting it to the right place)
* [ ] I have included full stderr/stdout output from ffmpeg
